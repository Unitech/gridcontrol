
module.exports = function(context, cb) {
  // nothing!
};
