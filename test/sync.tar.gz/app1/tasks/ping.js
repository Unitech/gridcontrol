
module.exports = function(context, cb) {
  cb(null, { ping : true });
};
